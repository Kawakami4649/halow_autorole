#!/bin/bash

export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin

AP_IP=$(grep -E "^dhcp-option=3," /etc/dnsmasq.d/halow.conf | cut -d',' -f2)

if [[ -z "$AP_IP" ]]; then
    echo "[!] AP_IP not found"
    exit 1
fi

halow_ok() {
    nohup ip neigh flush "$AP_IP"
    sleep 5

    ping -c10 -W1 "$AP_IP" 2>/dev/null

    ip link show wlan0 | grep -q "state UP" || return 1

    if ping -c10 -W1 "$AP_IP" 2>/dev/null | grep -q "time="; then
        return 0
    fi

    return 1
}

if halow_ok; then
    echo "[*] HaLow OK → no action"
    exit 0
fi

if ip neigh show | grep -q "$AP_IP"; then
    echo "[!] STA DOWN → restarting HaLow"
    nohup /usr/local/bin/halow_autorole.sh sta >> /var/log/halow_autorole.log 2>&1 &
else
    echo "[!] AP DOWN → restarting HaLow"
    nohup /usr/local/bin/halow_autorole.sh ap >> /var/log/halow_autorole.log 2>&1 &
fi

exit 0
