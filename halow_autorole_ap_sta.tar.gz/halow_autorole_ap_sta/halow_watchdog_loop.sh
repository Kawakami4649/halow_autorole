#!/bin/bash

export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin

sleep 10

# 最後に wlan0 を再起動した時間を記録
LAST_RESET=$(date +%s)

while true; do
    # 監視スクリプトを実行
    /usr/local/bin/halow_watchdog.sh

    # 現在時刻
    NOW=$(date +%s)

    # 経過時間（秒）
    ELAPSED=$(( NOW - LAST_RESET ))

    # 3時間 = 10800秒
    if [ $ELAPSED -ge 10800 ]; then
        echo "$(date): Restarting wlan0..." >> /var/log/halow_loop.log

        ip link set wlan0 down
        sleep 3
        ip link set wlan0 up

        LAST_RESET=$NOW
    fi

    sleep 60
done

