#!/bin/bash

RC_LOCAL="/etc/rc.local"
LINE1='sleep 60'
LINE2='/usr/bin/nohup /usr/local/bin/halow_watchdog_loop.sh >/var/log/halow_loop.log 2>&1 &'

# rc.local が存在しない場合は作成
if [ ! -f "$RC_LOCAL" ]; then
    echo "#!/bin/bash" > "$RC_LOCAL"
    echo "" >> "$RC_LOCAL"
    echo "exit 0" >> "$RC_LOCAL"
    chmod +x "$RC_LOCAL"
fi

# すでに sleep 20 が存在するか確認
if grep -Fxq "$LINE1" "$RC_LOCAL"; then
    echo "[*] rc.local already contains sleep 20."
else
    # exit 0 の直前に sleep 20 を挿入
    sed -i "/^exit 0/i $LINE1" "$RC_LOCAL"
    echo "[+] Added sleep 20 to rc.local"
fi

# すでに watchdog 行が存在するか確認
if grep -Fxq "$LINE2" "$RC_LOCAL"; then
    echo "[*] rc.local already contains watchdog entry."
else
    # exit 0 の直前に watchdog 行を挿入
    sed -i "/^exit 0/i $LINE2" "$RC_LOCAL"
    echo "[+] Added watchdog entry to rc.local"
fi

