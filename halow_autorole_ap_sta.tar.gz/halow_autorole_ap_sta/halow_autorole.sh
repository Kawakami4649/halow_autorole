#!/bin/bash

SCRIPT_DIR="/home/pi/nrc_pkg/script"
STARTPY="$SCRIPT_DIR/start.py"

reset_wlan0() {
    echo "[*] Resetting wlan0..."
    sudo killall wpa_supplicant 2>/dev/null
    sudo rmmod nrc 2>/dev/null
    sleep 1
}

start_ap() {
    echo "[*] Starting HALOW AP mode"

    # AP の IP を dnsmasq 設定から取得
    AP_IP=$(grep -E "^dhcp-option=3," /etc/dnsmasq.d/halow.conf | cut -d',' -f2)

    reset_wlan0
    sleep 1

    cd $SCRIPT_DIR
    # AP モード = 1
    sudo /usr/bin/python3 start.py 1 3 JP

    sudo systemctl enable dnsmasq
    sudo systemctl restart dnsmasq
}

start_sta() {
    echo "[*] Starting HALOW STA mode"

    sudo systemctl stop dnsmasq
    sudo systemctl disable dnsmasq

    reset_wlan0
    sleep 1

    cd $SCRIPT_DIR
    # STA モード = 0
    sudo /usr/bin/python3 start.py 0 3 JP
}

case "$1" in
    ap)  start_ap ;;
    sta) start_sta ;;
    *)   echo "Usage: $0 {ap|sta}" ;;
esac

