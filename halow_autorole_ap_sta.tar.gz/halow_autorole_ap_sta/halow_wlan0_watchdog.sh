#!/bin/bash

WIFI="wlan0"
BRIDGE="br0"

# ======== 1. wlan0 の状態チェック ========

RESET_FLAG=0

# wlan0 が LOWER_UP か？
ip link show $WIFI | grep -q "LOWER_UP"
if [ $? -ne 0 ]; then
    RESET_FLAG=1
fi

# batman-adv の隣接ノードがゼロなら異常
NEIGH=$(batctl n | wc -l)
if [ "$NEIGH" -eq 0 ]; then
    RESET_FLAG=1
fi

# ======== 2. リセットが必要な場合のみ実行 ========

if [ "$RESET_FLAG" -eq 1 ]; then
    echo "[HALOW-WATCHDOG] wlan0 reset triggered"

    # wlan0 を安全にリセット
    ip link set $WIFI down
    sleep 2
    ip link set $WIFI up
    sleep 3

    # batman-adv に再アタッチ
    batctl if add $WIFI 2>/dev/null

    # br0 に入っていなければ追加
    brctl show $BRIDGE | grep -q $WIFI
    if [ $? -ne 0 ]; then
        brctl addif $BRIDGE $WIFI
    fi
fi

