#!/bin/bash

SCRIPT_DIR="/home/pi/nrc_pkg/script"

echo "==============================="
echo " 802.11ah HaLow Mesh Status"
echo "==============================="

# Mesh ロール確認
ROLE=$(sudo $SCRIPT_DIR/cli_app wlan0 mesh_status | grep "role" | awk '{print $2}')
echo "[*] Mesh Role: $ROLE"

# Peer 数確認
PEER_COUNT=$(sudo $SCRIPT_DIR/cli_app wlan0 mesh_status | grep -c "peer")
echo "[*] Peer Count: $PEER_COUNT"

echo ""
echo "---- Peer List ----"

if [ "$PEER_COUNT" -eq 0 ]; then
    echo "No peers detected."
else
    sudo $SCRIPT_DIR/cli_app wlan0 mesh_status | grep "peer"
fi

echo ""
echo "---- Link Quality ----"

# RSSI / SNR 取得
sudo $SCRIPT_DIR/cli_app wlan0 get_rssi
sudo $SCRIPT_DIR/cli_app wlan0 get_snr

echo ""
echo "---- Interface Info ----"
ip addr show wlan0

echo ""
echo "---- Routing Table ----"
ip route

echo ""
echo "==============================="
echo " Mesh Status Check Complete"
echo "==============================="

