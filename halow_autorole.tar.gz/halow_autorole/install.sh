sudo cp mesh_status.sh /usr/local/bin/
mv -n ~/nrc_pkg/script/start.py ~/nrc_pkg/script/start.py.orgin
cp start.py ~/nrc_pkg/script/
sudo cp halow.conf /etc/dnsmasq.d/
sudo cp halow_autorole.sh /usr/local/bin/
sudo cp halow_watchdog.sh /usr/local/bin/
sudo cp halow_watchdog_loop.sh /usr/local/bin/
sudo cp add_to_rc_local.sh /usr/local/bin/
sudo cp halow_autorole.service.mp /etc/systemd/system/halow_autorole.service
sudo /usr/local/bin/add_to_rc_local.sh
sudo systemctl daemon-reload
sudo systemctl enable halow_autorole.service
