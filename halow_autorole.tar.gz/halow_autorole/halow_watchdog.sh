#!/bin/bash

export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin

MPP_IP=$(grep -E "^dhcp-option=3," /etc/dnsmasq.d/halow.conf | cut -d',' -f2)

mesh_ok() {
    if ! ip link show wlan0 | grep -q "state UP"; then
        return 1
    fi

    if ping -c1 -W1 "$MPP_IP" >/dev/null 2>&1; then
        return 0
    fi

    return 1
}

if mesh_ok; then
    echo "[*] Mesh OK → no action"
    exit 0
fi

echo "[!] Mesh DOWN → restarting HaLow"

nohup /usr/local/bin/halow_autorole.sh mpp >> /var/log/halow_autorole.log 2>&1 &

