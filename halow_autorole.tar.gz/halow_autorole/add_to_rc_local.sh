#!/bin/bash

RC_LOCAL="/etc/rc.local"
LINE='nohup /usr/local/bin/halow_watchdog_loop.sh >/var/log/halow_loop.log 2>&1 &'

# rc.local が存在しない場合は作成
if [ ! -f "$RC_LOCAL" ]; then
    echo "#!/bin/bash" > "$RC_LOCAL"
    echo "" >> "$RC_LOCAL"
    echo "exit 0" >> "$RC_LOCAL"
    chmod +x "$RC_LOCAL"
fi

# すでに行が存在するか確認
if grep -Fxq "$LINE" "$RC_LOCAL"; then
    echo "[*] rc.local already contains the watchdog entry. No changes made."
    exit 0
fi

# exit 0 の直前に挿入
sed -i "/^exit 0/i $LINE" "$RC_LOCAL"

echo "[+] Added watchdog entry to rc.local:"
echo "    $LINE"

