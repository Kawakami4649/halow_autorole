#!/bin/bash

SCRIPT_DIR="/home/pi/nrc_pkg/script"
STARTPY="$SCRIPT_DIR/start.py"

reset_wlan0() {
    echo "[*] Resetting wlan0..."
    sudo killall wpa_supplicant 2>/dev/null
    sudo rmmod nrc 2>/dev/null
    sleep 1
}

start_mpp() {
    echo "[*] Starting MPP mode"

    MPP_IP=$(grep -E "^dhcp-option=3," /etc/dnsmasq.d/halow.conf | cut -d',' -f2)

    reset_wlan0
    sleep 1

    cd /home/pi/nrc_pkg/script
    sudo /usr/bin/python3 start.py 4 3 JP 0 "$MPP_IP"

    sudo systemctl enable dnsmasq
    sudo systemctl restart dnsmasq
}

start_mp() {
    echo "[*] Starting MP mode"

    sudo systemctl stop dnsmasq
    sudo systemctl dsable dnsmasq
    reset_wlan0
    sleep 1

    cd $SCRIPT_DIR
    sudo /usr/bin/python3 start.py 4 3 JP 1
}

case "$1" in
    mpp) start_mpp ;;
    mp)  start_mp ;;
esac

