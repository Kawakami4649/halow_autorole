#!/bin/bash

export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin

sleep 120
while true; do
    /usr/local/bin/halow_watchdog.sh
    sleep 60
done

