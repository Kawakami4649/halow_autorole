sudo cp halow_autorole.sh /usr/local/bin/
sudo cp halow_watchdog.sh /usr/local/bin/
sudo cp halow_watchdog_loop.sh /usr/local/bin/
sudo cp halow_autorole.service.mp /etc/systemd/system/halow_autorole.service
sudo systemctl daemon-reload
sudo systemctl enable halow_autorole.service
