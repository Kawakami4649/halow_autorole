#!/bin/bash

export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin

MPP_IP=$(grep -E "^dhcp-option=3," /etc/dnsmasq.d/halow.conf | cut -d',' -f2)

if [[ -z "$MPP_IP" ]]; then
    echo "[!] MPP_IP not found"
    exit 1
fi

mesh_ok() {
    nohup ip neigh flush "$MPP_IP"
    sleep 5

    ping -c10 -W1 "$MPP_IP" 2>/dev/null

    ip link show wlan0 | grep -q "state UP" || return 1

    if ping -c10 -W1 "$MPP_IP" 2>/dev/null | grep -q "time="; then
        return 0
    fi

    return 1
}

if mesh_ok; then
    echo "[*] Mesh OK → no action"
    exit 0
fi

if ip neigh show | grep -q "$MPP_IP"; then
    echo "[!] MP DOWN → restarting HaLow"
    nohup /usr/local/bin/halow_autorole.sh mp >> /var/log/halow_autorole.log 2>&1 &
else
    echo "[!] MPP DOWN → restarting HaLow"
    nohup /usr/local/bin/halow_autorole.sh mpp >> /var/log/halow_autorole.log 2>&1 &
fi

exit 0

